/*
 * File: WASPMOTEfminBMEintervalMode_initialize.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:55:56
 */

#ifndef __WASPMOTEFMINBMEINTERVALMODE_INITIALIZE_H__
#define __WASPMOTEFMINBMEINTERVALMODE_INITIALIZE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WASPMOTEfminBMEintervalMode_types.h"

/* Function Declarations */
extern void WASPMOTEfminBMEintervalMode_initialize(void);

#endif

/*
 * File trailer for WASPMOTEfminBMEintervalMode_initialize.h
 *
 * [EOF]
 */
