/* 
 * File: _coder_WASPMOTEfminbnd_api.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 04:07:22 
 */

#ifndef ___CODER_WASPMOTEFMINBND_API_H__
#define ___CODER_WASPMOTEFMINBND_API_H__
/* Include Files */ 
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Function Declarations */ 
extern void WASPMOTEfminbnd_initialize(emlrtContext *aContext);
extern void WASPMOTEfminbnd_terminate(void);
extern void WASPMOTEfminbnd_atexit(void);
extern void WASPMOTEfminbnd_api(const mxArray *prhs[8], const mxArray *plhs[1]);
extern real_T WASPMOTEfminbnd(real_T ax, real_T bx, real_T zhlocal[3], real_T alocal[2], real_T blocal[2], real_T invKkhkh[16], real_T KskhinvKkhkh[8], real_T Kssifkh[4]);
extern void WASPMOTEfminbnd_xil_terminate(void);

#endif
/* 
 * File trailer for _coder_WASPMOTEfminbnd_api.h 
 *  
 * [EOF] 
 */
