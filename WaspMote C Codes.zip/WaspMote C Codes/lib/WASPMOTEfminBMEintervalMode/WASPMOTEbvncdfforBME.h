/*
 * File: WASPMOTEbvncdfforBME.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:55:56
 */

#ifndef __WASPMOTEBVNCDFFORBME_H__
#define __WASPMOTEBVNCDFFORBME_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WASPMOTEfminBMEintervalMode_types.h"

/* Function Declarations */
extern double WASPMOTEbvncdfforBME(const double b[2], double rho);

#endif

/*
 * File trailer for WASPMOTEbvncdfforBME.h
 *
 * [EOF]
 */
