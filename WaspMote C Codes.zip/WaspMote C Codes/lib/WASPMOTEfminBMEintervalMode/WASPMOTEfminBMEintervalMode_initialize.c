/*
 * File: WASPMOTEfminBMEintervalMode_initialize.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:55:56
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEfminBMEintervalMode.h"
#include "WASPMOTEfminBMEintervalMode_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void WASPMOTEfminBMEintervalMode_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for WASPMOTEfminBMEintervalMode_initialize.c
 *
 * [EOF]
 */
