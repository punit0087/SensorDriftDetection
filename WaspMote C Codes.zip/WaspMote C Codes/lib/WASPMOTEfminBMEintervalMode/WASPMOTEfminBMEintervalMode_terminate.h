/*
 * File: WASPMOTEfminBMEintervalMode_terminate.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:55:56
 */

#ifndef __WASPMOTEFMINBMEINTERVALMODE_TERMINATE_H__
#define __WASPMOTEFMINBMEINTERVALMODE_TERMINATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WASPMOTEfminBMEintervalMode_types.h"

/* Function Declarations */
extern void WASPMOTEfminBMEintervalMode_terminate(void);

#endif

/*
 * File trailer for WASPMOTEfminBMEintervalMode_terminate.h
 *
 * [EOF]
 */
