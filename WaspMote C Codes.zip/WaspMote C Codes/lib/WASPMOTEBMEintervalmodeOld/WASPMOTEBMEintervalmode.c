/*
 * File: WASPMOTEBMEintervalmode.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEBMEintervalmode.h"
#include "WASPMOTEfminBMEintervalMode.h"

/* Function Definitions */

/*
 * order=0;
 *  dmax=100;
 *
 *  nk=1;           % nk is the number of estimation points
 * Arguments    : void
 * Return Type  : double
 */
double WASPMOTEBMEintervalmode(void)
{
  double zk;
  double q;
  double r;
  int i;
  static const double a[5] = { 0.82859407764555737, 1.3797603440464916,
    1.2347546868455128, 0.44036090952477169, 0.37161547288273783 };

  static const double b[5] = { 21.0475, 21.4999, 21.2314, 21.2843, 21.5466 };

  double mkest;
  double zest[5];
  double zhlocal[3];
  static const double b_zhlocal[3] = { 21.0475, 21.4999, 21.2314 };

  double alocal[2];
  double blocal[2];
  double varargin_1[6];
  double b_a;
  int ix;
  boolean_T exitg2;
  double b_b;
  boolean_T exitg1;
  double v;
  double w;
  double d;
  double e;
  double fx;
  double fv;
  double fw;
  double xm;
  double tol1;
  double tol2;
  double p;
  double b_q;
  double b_d;
  double c_q;

  /* %% Input for Main Script */
  /*  nh is the number of high precion sensors (hard)  data */
  /*  ns is the number of low precision sensors (soft)  data */
  /*  ck0=[24.5,20]; */
  /*  chlocal=[21.5,23;33.5,28;22.5,8]; */
  /*  cslocal=[19.5,19;22.5,15]; */
  /*  ablocal=[20.7843,21.7843;21.0466,22.0466]; */
  /*  str='WASPMOTEfminBMEintervalMode';  %% Input Function for FminBND */
  /*  funfcn = str2func(str); */
  /*  output of main script  */
  /* %%%%% Main code starts here */
  /* %% Prepare the data for Regression  */
  /*  compute the mean assuming uniform distribution */
  /*  compute the variance assuming uniform distribution */
  /*  c=[chlocal;cslocal]; %c=[21.5000000000000,23;33.5000000000000,28;22.5000000000000,8;19.5000000000000,19;22.5000000000000,15]; */
  /* % based on data */
  /* %%%%%%%%%   REGRESSION */
  /*  XtinvK=X'*inv(K); %% For inverse, I am giving you a waspmode code too. */
  /*  mkest=invXtinvKX*XtinvK*z; */
  q = 0.0;
  r = 0.0;
  for (i = 0; i < 5; i++) {
    q += a[i];
    r += a[i] * b[i];
  }

  mkest = 1.0 / q * r;
  for (i = 0; i < 5; i++) {
    zest[i] = mkest;
  }

  /*  vbest=invXtinvKX; */
  for (i = 0; i < 3; i++) {
    zhlocal[i] = b_zhlocal[i] - zest[i];
  }

  /*  substract the mean from the hard data */
  for (i = 0; i < 2; i++) {
    alocal[i] = (20.7843 + 0.26229999999999976 * (double)i) - zest[3 + i];

    /*  substract the mean from the soft data */
    blocal[i] = (21.7843 + 0.26229999999999976 * (double)i) - zest[3 + i];
  }

  /* %%%%%%%%%%%%% */
  /* %%%%%%%%%Prepare the data for Minimization Problem  */
  for (i = 0; i < 3; i++) {
    varargin_1[i] = zhlocal[i];
  }

  for (i = 0; i < 2; i++) {
    varargin_1[i + 3] = alocal[i];
  }

  varargin_1[5] = 0.0;
  i = 1;
  b_a = varargin_1[0];
  if (rtIsNaN(varargin_1[0])) {
    ix = 2;
    exitg2 = false;
    while ((!exitg2) && (ix < 7)) {
      i = ix;
      if (!rtIsNaN(varargin_1[ix - 1])) {
        b_a = varargin_1[ix - 1];
        exitg2 = true;
      } else {
        ix++;
      }
    }
  }

  if (i < 6) {
    while (i + 1 < 7) {
      if (varargin_1[i] < b_a) {
        b_a = varargin_1[i];
      }

      i++;
    }
  }

  /*  initialize the minimum and maximum guess */
  for (i = 0; i < 3; i++) {
    varargin_1[i] = zhlocal[i];
  }

  for (i = 0; i < 2; i++) {
    varargin_1[i + 3] = blocal[i];
  }

  varargin_1[5] = 0.0;
  i = 1;
  b_b = varargin_1[0];
  if (rtIsNaN(varargin_1[0])) {
    ix = 2;
    exitg1 = false;
    while ((!exitg1) && (ix < 7)) {
      i = ix;
      if (!rtIsNaN(varargin_1[ix - 1])) {
        b_b = varargin_1[ix - 1];
        exitg1 = true;
      } else {
        ix++;
      }
    }
  }

  if (i < 6) {
    while (i + 1 < 7) {
      if (varargin_1[i] > b_b) {
        b_b = varargin_1[i];
      }

      i++;
    }
  }

  /*  values to be used by fminbnd */
  /* %% Minimization Problem  */
  /*  zk=WASPMOTEfminbnd(@WASPMOTEfminBMEintervalMode,zkmin,zkmax,zhlocal,alocal,blocal,invKkhkh,KskhinvKkhkh,Kssifkh); */
  /* FMINBND Single-variable bounded nonlinear function minimization. */
  /*    X = FMINBND(FUN,x1,x2) attempts to find  a local minimizer X of the function  */
  /*    FUN in the interval x1 < X < x2.  FUN is a function handle.  FUN accepts  */
  /*    scalar input X and returns a scalar function value F evaluated at X. */
  /*  function xf = WASPMOTEfminbnd(funfcn,ax,bx,zhlocal,alocal,blocal,invKkhkh,KskhinvKkhkh,Kssifkh) */
  /* % I am attaching a C code(brent.c) and header files( brent.h) for this code. we just need to define our function handle ( funfcn  variable) here. In this programm  */
  /* %I am definig function handler inside program, while in C code, they pass function handlers in function arguments.  */
  /* % Input Function for FminBND */
  /*  xf = []; */
  /*  fx = []; */
  v = b_a + 0.3819660112501051 * (b_b - b_a);
  w = v;
  zk = v;
  d = 0.0;
  e = 0.0;
  fx = WASPMOTEfminBMEintervalMode(v, zhlocal, alocal, blocal);
  fv = fx;
  fw = fx;
  xm = 0.5 * (b_a + b_b);
  tol1 = 1.4901161193847656E-8 * fabs(v) + 3.3333333333333335E-5;
  tol2 = 2.0 * tol1;

  /*  Main loop */
  while (fabs(zk - xm) > tol2 - 0.5 * (b_b - b_a)) {
    i = 1;

    /*  Is a parabolic fit possible */
    if (fabs(e) > tol1) {
      /*  Yes, so fit parabola */
      i = 0;
      r = (zk - w) * (fx - fv);
      q = (zk - v) * (fx - fw);
      p = (zk - v) * q - (zk - w) * r;
      q = 2.0 * (q - r);
      if (q > 0.0) {
        p = -p;
      }

      q = fabs(q);
      r = e;
      e = d;

      /*  Is the parabola acceptable */
      if ((fabs(p) < fabs(0.5 * q * r)) && (p > q * (b_a - zk)) && (p < q * (b_b
            - zk))) {
        /*  Yes, parabolic interpolation step */
        d = p / q;
        q = zk + d;

        /*  f must not be evaluated too close to ax or bx */
        if ((q - b_a < tol2) || (b_b - q < tol2)) {
          q = xm - zk;
          if (q < 0.0) {
            b_q = -1.0;
          } else if (q > 0.0) {
            b_q = 1.0;
          } else if (q == 0.0) {
            b_q = 0.0;
          } else {
            b_q = q;
          }

          d = tol1 * (b_q + (double)(xm - zk == 0.0));
        }
      } else {
        /*  Not acceptable, must do a golden section step */
        i = 1;
      }
    }

    if (i != 0) {
      /*  A golden-section step is required */
      if (zk >= xm) {
        e = b_a - zk;
      } else {
        e = b_b - zk;
      }

      d = 0.3819660112501051 * e;
    }

    /*  The function must not be evaluated too close to xf */
    q = fabs(d);
    if (d < 0.0) {
      b_d = -1.0;
    } else if (d > 0.0) {
      b_d = 1.0;
    } else if (d == 0.0) {
      b_d = 0.0;
    } else {
      b_d = d;
    }

    if ((q >= tol1) || rtIsNaN(tol1)) {
      c_q = q;
    } else {
      c_q = tol1;
    }

    q = zk + (b_d + (double)(d == 0.0)) * c_q;
    r = WASPMOTEfminBMEintervalMode(q, zhlocal, alocal, blocal);

    /*  Update a, b, v, w, x, xm, tol1, tol2 */
    if (r <= fx) {
      if (q >= zk) {
        b_a = zk;
      } else {
        b_b = zk;
      }

      v = w;
      fv = fw;
      w = zk;
      fw = fx;
      zk = q;
      fx = r;
    } else {
      /*  fu > fx */
      if (q < zk) {
        b_a = q;
      } else {
        b_b = q;
      }

      if ((r <= fw) || (w == zk)) {
        v = w;
        fv = fw;
        w = q;
        fw = r;
      } else {
        if ((r <= fv) || (v == zk) || (v == w)) {
          v = q;
          fv = r;
        }
      }
    }

    xm = 0.5 * (b_a + b_b);
    tol1 = 1.4901161193847656E-8 * fabs(zk) + 3.3333333333333335E-5;
    tol2 = 2.0 * tol1;
  }

  /*  while */
  /*  fval = fx; */
  zk += mkest;

  /*  add the mean to the mode estimate */
  return zk;
}

/*
 * File trailer for WASPMOTEBMEintervalmode.c
 *
 * [EOF]
 */
