/*
 * File: WASPMOTEfminBMEintervalMode.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52
 */

#ifndef __WASPMOTEFMINBMEINTERVALMODE_H__
#define __WASPMOTEFMINBMEINTERVALMODE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WASPMOTEBMEintervalmode_types.h"

/* Function Declarations */
extern double WASPMOTEfminBMEintervalMode(double zk, const double zh[3], const
  double a[2], const double b[2]);

#endif

/*
 * File trailer for WASPMOTEfminBMEintervalMode.h
 *
 * [EOF]
 */
