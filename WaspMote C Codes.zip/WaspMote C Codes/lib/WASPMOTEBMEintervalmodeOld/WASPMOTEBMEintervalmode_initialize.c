/*
 * File: WASPMOTEBMEintervalmode_initialize.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEBMEintervalmode.h"
#include "WASPMOTEBMEintervalmode_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void WASPMOTEBMEintervalmode_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for WASPMOTEBMEintervalmode_initialize.c
 *
 * [EOF]
 */
