/*
 * File: WASPMOTEfminBMEintervalMode.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEBMEintervalmode.h"
#include "WASPMOTEfminBMEintervalMode.h"

/* Function Declarations */
static double rt_powd_snf(double u0, double u1);

/* Function Definitions */

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_powd_snf(double u0, double u1)
{
  double y;
  double d0;
  double d1;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = rtNaN;
  } else {
    d0 = fabs(u0);
    d1 = fabs(u1);
    if (rtIsInf(u1)) {
      if (d0 == 1.0) {
        y = rtNaN;
      } else if (d0 > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = rtNaN;
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/*
 * Arguments    : double zk
 *                const double zh[3]
 *                const double a[2]
 *                const double b[2]
 * Return Type  : double
 */
double WASPMOTEfminBMEintervalMode(double zk, const double zh[3], const double
  a[2], const double b[2])
{
  double f;
  double zkh[4];
  int i;
  double P;
  double XL0[2];
  double XU0[2];
  int i0;
  double msifkh[2];
  static const double b_a[8] = { 0.273424511692489, 0.44806457328486,
    0.435624332363198, 0.0485231814344831, -0.0328775008809324,
    -0.0131264156019486, 0.121124463523203, 0.337767948574806 };

  double hyperectangle[8];
  int k;
  double hk;
  double ssq;
  double b_hyperectangle;
  double b_f[12];
  static const double y[12] = { 0.99998743924555655, 0.99966040809884393,
    0.99804536548430067, 0.99372164669567808, 0.98530894471111852,
    0.971996407621067, 0.861822094348451, 0.87193344412811569,
    0.88867147524118384, 0.90977294787743568, 0.93245988648157552,
    0.95395007738405913 };

  static const double b_b[12] = { 0.0035441154669942961, 0.018428019458317655,
    0.04421124874620988, 0.079236060631015584, 0.12120666354982941,
    0.16734273924772777, 0.37172288825353345, 0.35786387897060007,
    0.33365929442893705, 0.30037818183510639, 0.25988480817166754,
    0.21459245703412044 };

  static const double w[12] = { 0.047175336386511772, 0.1069393259953183,
    0.16007832854334639, 0.2031674267230659, 0.23349253653835469,
    0.24914704581340291, 0.047175336386511772, 0.1069393259953183,
    0.16007832854334639, 0.2031674267230659, 0.23349253653835469,
    0.24914704581340291 };

  static const signed char iv0[4] = { 0, 1, 1, 2 };

  double dv0[1];
  boolean_T x;
  double dv1[1];
  double b_zkh[4];
  static const double c_b[16] = { 3.03751008042635, -1.83460168015313,
    -0.301101335707301, -0.380947972560897, -1.83460168015313, 2.92148073795342,
    -0.164284024311862, -0.0253344226212212, -0.301101335707301,
    -0.164284024311862, 1.80692806065874, -0.00425196850242675,
    -0.380947972560897, -0.0253344226212212, -0.00425196850242675,
    1.794761236066 };

  zkh[0] = zk;
  for (i = 0; i < 3; i++) {
    zkh[i + 1] = zh[i];
  }

  /*  tol = 1e-8; */
  P = 0.0;
  for (i0 = 0; i0 < 2; i0++) {
    msifkh[i0] = 0.0;
    for (i = 0; i < 4; i++) {
      msifkh[i0] += b_a[i0 + (i << 1)] * zkh[i];
    }

    /*  compute the conditional mean */
    /* % compute the Sigma ( positive semidefinite) */
    /*  %%% MVNCDF CODE STARTS WHICH CALLS BVNCDF HERE */
    XL0[i0] = (a[i0] - msifkh[i0]) / (0.56578540219959461 + 0.020243115322477023
      * (double)i0);
    XU0[i0] = (b[i0] - msifkh[i0]) / (0.56578540219959461 + 0.020243115322477023
      * (double)i0);
    hyperectangle[i0 << 2] = XL0[i0];
  }

  hyperectangle[1] = XL0[0];
  hyperectangle[5] = XU0[1];
  hyperectangle[2] = XU0[0];
  hyperectangle[6] = XL0[1];
  for (i0 = 0; i0 < 2; i0++) {
    hyperectangle[3 + (i0 << 2)] = XU0[i0];
  }

  for (i = 0; i < 4; i++) {
    /*  CDF for the bivariate normal. */
    /*   n = size(b,1); */
    /* %% Compute Normal CDF here  */
    for (k = 0; k < 2; k++) {
      hk = fabs(hyperectangle[i + (k << 2)]) / 1.4142135623730951;
      ssq = 1.0 / (1.0 + 0.3275911 * hk);
      hk *= -hk;
      hk = exp(hk);
      if (hyperectangle[i + (k << 2)] < 0.0) {
        b_hyperectangle = -1.0;
      } else if (hyperectangle[i + (k << 2)] > 0.0) {
        b_hyperectangle = 1.0;
      } else if (hyperectangle[i + (k << 2)] == 0.0) {
        b_hyperectangle = 0.0;
      } else {
        b_hyperectangle = hyperectangle[i + (k << 2)];
      }

      XL0[k] = 0.5 * (1.0 + b_hyperectangle * (1.0 - ((((1.061405429 * ssq +
        -1.453152027) * ssq + 1.421413741) * ssq + -0.284496736) * ssq +
        0.254829592) * ssq * hk));
    }

    /* % n_cdf  is norm cdf */
    /*  12 point Gauss Legendre abscissas and weights */
    /* % function comes here */
    /* % product of columns from Phi or normcdf */
    /* % arc sin function available in math.h */
    /* % duplicate w  */
    /* % make reverse order */
    /* % duplicate y with negative sign */
    /*  always positive */
    hk = -hyperectangle[i] * -hyperectangle[4 + i];
    ssq = (-hyperectangle[i] * -hyperectangle[i] + -hyperectangle[4 + i] *
           -hyperectangle[4 + i]) / 2.0;
    for (i0 = 0; i0 < 12; i0++) {
      b_f[i0] = w[i0] * exp(-(ssq - hk * b_b[i0]) / y[i0]);
    }

    hk = b_f[0];
    for (k = 0; k < 11; k++) {
      hk += b_f[k + 1];
    }

    P += rt_powd_snf(-1.0, iv0[i]) * (XL0[0] * XL0[1] + 0.38440832878064912 * hk
      / 2.0 / 6.2831853071795862);
  }

  dv0[0] = P;
  x = (P < 0.0);
  k = 0;
  if (x) {
    k = 1;
  }

  i0 = 0;
  while (i0 <= k - 1) {
    dv0[0] = 0.0;
    i0 = 1;
  }

  dv1[0] = dv0[0];
  x = (dv0[0] > 1.0);
  k = 0;
  if (x) {
    k = 1;
  }

  i0 = 0;
  while (i0 <= k - 1) {
    dv1[0] = 1.0;
    i0 = 1;
  }

  /*  [P]=WASPMOTEmvncdfforBME(XL,XU,mu,Sigma); */
  i = 1;
  hk = dv1[0];
  if (rtIsNaN(dv1[0])) {
    i = 2;
    hk = 9.88131291682493E-324;
  }

  if ((i < 2) && (9.88131291682493E-324 > hk)) {
    hk = 9.88131291682493E-324;
  }

  /*  make sure that log(P) does not yield -Inf */
  ssq = 0.0;
  for (i0 = 0; i0 < 4; i0++) {
    b_zkh[i0] = 0.0;
    for (i = 0; i < 4; i++) {
      b_zkh[i0] += zkh[i] * c_b[i + (i0 << 2)];
    }

    ssq += b_zkh[i0] * zkh[i0];
  }

  f = 0.5 * ssq - log(hk);

  /*  compute the value of the -log posterior pdf */
  return f;
}

/*
 * File trailer for WASPMOTEfminBMEintervalMode.c
 *
 * [EOF]
 */
