/*
 * File: WASPMOTEBMEintervalmode_initialize.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52
 */

#ifndef __WASPMOTEBMEINTERVALMODE_INITIALIZE_H__
#define __WASPMOTEBMEINTERVALMODE_INITIALIZE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WASPMOTEBMEintervalmode_types.h"

/* Function Declarations */
extern void WASPMOTEBMEintervalmode_initialize(void);

#endif

/*
 * File trailer for WASPMOTEBMEintervalmode_initialize.h
 *
 * [EOF]
 */
