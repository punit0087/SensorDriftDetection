/* 
 * File: _coder_WASPMOTEbvncdfforBME_api.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 03:45:13 
 */

#ifndef ___CODER_WASPMOTEBVNCDFFORBME_API_H__
#define ___CODER_WASPMOTEBVNCDFFORBME_API_H__
/* Include Files */ 
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Function Declarations */ 
extern void WASPMOTEbvncdfforBME_initialize(emlrtContext *aContext);
extern void WASPMOTEbvncdfforBME_terminate(void);
extern void WASPMOTEbvncdfforBME_atexit(void);
extern void WASPMOTEbvncdfforBME_api(const mxArray *prhs[2], const mxArray *plhs[1]);
extern real_T WASPMOTEbvncdfforBME(real_T b[2], real_T rho);
extern void WASPMOTEbvncdfforBME_xil_terminate(void);

#endif
/* 
 * File trailer for _coder_WASPMOTEbvncdfforBME_api.h 
 *  
 * [EOF] 
 */
