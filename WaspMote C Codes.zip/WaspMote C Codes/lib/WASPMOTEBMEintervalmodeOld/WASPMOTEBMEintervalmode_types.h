/* 
 * File: WASPMOTEBMEintervalmode_types.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52 
 */

#ifndef __WASPMOTEBMEINTERVALMODE_TYPES_H__
#define __WASPMOTEBMEINTERVALMODE_TYPES_H__

/* Include Files */ 
#include "rtwtypes.h"

#endif
/* 
 * File trailer for WASPMOTEBMEintervalmode_types.h 
 *  
 * [EOF] 
 */
