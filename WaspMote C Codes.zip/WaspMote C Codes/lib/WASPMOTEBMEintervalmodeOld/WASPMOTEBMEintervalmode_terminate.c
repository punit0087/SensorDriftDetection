/*
 * File: WASPMOTEBMEintervalmode_terminate.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEBMEintervalmode.h"
#include "WASPMOTEBMEintervalmode_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void WASPMOTEBMEintervalmode_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for WASPMOTEBMEintervalmode_terminate.c
 *
 * [EOF]
 */
