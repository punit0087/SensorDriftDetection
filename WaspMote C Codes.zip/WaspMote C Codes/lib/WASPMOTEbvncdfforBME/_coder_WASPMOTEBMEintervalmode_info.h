/* 
 * File: _coder_WASPMOTEBMEintervalmode_info.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52 
 */

#ifndef ___CODER_WASPMOTEBMEINTERVALMODE_INFO_H__
#define ___CODER_WASPMOTEBMEINTERVALMODE_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_WASPMOTEBMEintervalmode_info.h 
 *  
 * [EOF] 
 */
