/*
 * File: WASPMOTEbvncdfforBME_terminate.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:45:13
 */

#ifndef __WASPMOTEBVNCDFFORBME_TERMINATE_H__
#define __WASPMOTEBVNCDFFORBME_TERMINATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "WASPMOTEbvncdfforBME_types.h"

/* Function Declarations */
extern void WASPMOTEbvncdfforBME_terminate(void);

#endif

/*
 * File trailer for WASPMOTEbvncdfforBME_terminate.h
 *
 * [EOF]
 */
