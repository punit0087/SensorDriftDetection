/* 
 * File: _coder_WASPMOTEfminBMEintervalMode_info.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 03:55:56 
 */

#ifndef ___CODER_WASPMOTEFMINBMEINTERVALMODE_INFO_H__
#define ___CODER_WASPMOTEFMINBMEINTERVALMODE_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_WASPMOTEfminBMEintervalMode_info.h 
 *  
 * [EOF] 
 */
