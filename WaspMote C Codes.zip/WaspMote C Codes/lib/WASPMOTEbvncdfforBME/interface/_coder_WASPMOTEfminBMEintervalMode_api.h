/* 
 * File: _coder_WASPMOTEfminBMEintervalMode_api.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 03:55:56 
 */

#ifndef ___CODER_WASPMOTEFMINBMEINTERVALMODE_API_H__
#define ___CODER_WASPMOTEFMINBMEINTERVALMODE_API_H__
/* Include Files */ 
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Function Declarations */ 
extern void WASPMOTEfminBMEintervalMode_initialize(emlrtContext *aContext);
extern void WASPMOTEfminBMEintervalMode_terminate(void);
extern void WASPMOTEfminBMEintervalMode_atexit(void);
extern void WASPMOTEfminBMEintervalMode_api(const mxArray *prhs[7], const mxArray *plhs[1]);
extern real_T WASPMOTEfminBMEintervalMode(real_T zk, real_T zh[3], real_T a[2], real_T b[2], real_T invKkhkh[16], real_T KskhinvKkhkh[8], real_T Kssifkh[4]);
extern void WASPMOTEfminBMEintervalMode_xil_terminate(void);

#endif
/* 
 * File trailer for _coder_WASPMOTEfminBMEintervalMode_api.h 
 *  
 * [EOF] 
 */
