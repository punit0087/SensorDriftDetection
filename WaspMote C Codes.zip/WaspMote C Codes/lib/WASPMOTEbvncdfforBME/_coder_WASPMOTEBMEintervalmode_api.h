/* 
 * File: _coder_WASPMOTEBMEintervalmode_api.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 04:15:52 
 */

#ifndef ___CODER_WASPMOTEBMEINTERVALMODE_API_H__
#define ___CODER_WASPMOTEBMEINTERVALMODE_API_H__
/* Include Files */ 
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Function Declarations */ 
extern void WASPMOTEBMEintervalmode_initialize(emlrtContext *aContext);
extern void WASPMOTEBMEintervalmode_terminate(void);
extern void WASPMOTEBMEintervalmode_atexit(void);
extern void WASPMOTEBMEintervalmode_api(const mxArray *plhs[1]);
extern real_T WASPMOTEBMEintervalmode(void);
extern void WASPMOTEBMEintervalmode_xil_terminate(void);

#endif
/* 
 * File trailer for _coder_WASPMOTEBMEintervalmode_api.h 
 *  
 * [EOF] 
 */
