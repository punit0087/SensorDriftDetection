/*
 * File: WASPMOTEbvncdfforBME_terminate.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:45:13
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEbvncdfforBME.h"
#include "WASPMOTEbvncdfforBME_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void WASPMOTEbvncdfforBME_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for WASPMOTEbvncdfforBME_terminate.c
 *
 * [EOF]
 */
