/* 
 * File: WASPMOTEbvncdfforBME_types.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-Mar-2016 03:45:13 
 */

#ifndef __WASPMOTEBVNCDFFORBME_TYPES_H__
#define __WASPMOTEBVNCDFFORBME_TYPES_H__

/* Include Files */ 
#include "rtwtypes.h"

/* Type Definitions */ 
#ifndef struct_emxArray_real_T_1x20
#define struct_emxArray_real_T_1x20
struct emxArray_real_T_1x20
{
    double data[20];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x20*/
#ifndef typedef_emxArray_real_T_1x20
#define typedef_emxArray_real_T_1x20
typedef struct emxArray_real_T_1x20 emxArray_real_T_1x20;
#endif /*typedef_emxArray_real_T_1x20*/

#endif
/* 
 * File trailer for WASPMOTEbvncdfforBME_types.h 
 *  
 * [EOF] 
 */
