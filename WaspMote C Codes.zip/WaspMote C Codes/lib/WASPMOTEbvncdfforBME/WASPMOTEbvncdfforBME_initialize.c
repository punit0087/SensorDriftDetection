/*
 * File: WASPMOTEbvncdfforBME_initialize.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 03:45:13
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEbvncdfforBME.h"
#include "WASPMOTEbvncdfforBME_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void WASPMOTEbvncdfforBME_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for WASPMOTEbvncdfforBME_initialize.c
 *
 * [EOF]
 */
