/*
 * File: WASPMOTEfminBMEintervalMode.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:07:22
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEfminbnd.h"
#include "WASPMOTEfminBMEintervalMode.h"
#include "WASPMOTEbvncdfforBME.h"

/* Function Declarations */
static double rt_powd_snf(double u0, double u1);

/* Function Definitions */

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_powd_snf(double u0, double u1)
{
  double y;
  double d0;
  double d1;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = rtNaN;
  } else {
    d0 = fabs(u0);
    d1 = fabs(u1);
    if (rtIsInf(u1)) {
      if (d0 == 1.0) {
        y = rtNaN;
      } else if (d0 > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = rtNaN;
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/*
 * Arguments    : double zk
 *                const double zh[3]
 *                const double a[2]
 *                const double b[2]
 *                const double invKkhkh[16]
 *                const double KskhinvKkhkh[8]
 *                const double Kssifkh[4]
 * Return Type  : double
 */
double WASPMOTEfminBMEintervalMode(double zk, const double zh[3], const double
  a[2], const double b[2], const double invKkhkh[16], const double KskhinvKkhkh
  [8], const double Kssifkh[4])
{
  double f;
  double zkh[4];
  int i;
  double Sigma[4];
  int i0;
  double msifkh[2];
  double s[2];
  double Rho[4];
  double P;
  double XL0[2];
  double XU0[2];
  double b_XL0;
  double hyperectangle[8];
  static const signed char iv0[4] = { 0, 1, 1, 2 };

  double dv0[1];
  boolean_T x;
  double dv1[1];
  zkh[0] = zk;
  for (i = 0; i < 3; i++) {
    zkh[i + 1] = zh[i];
  }

  for (i0 = 0; i0 < 2; i0++) {
    msifkh[i0] = 0.0;
    for (i = 0; i < 4; i++) {
      msifkh[i0] += KskhinvKkhkh[i0 + (i << 1)] * zkh[i];
    }

    /*  compute the conditional mean */
    /* % compute the Sigma ( positive semidefinite) */
    for (i = 0; i < 2; i++) {
      Sigma[i + (i0 << 1)] = (Kssifkh[i + (i0 << 1)] + Kssifkh[i0 + (i << 1)]) /
        2.0;
    }
  }

  /*  %%% MVNCDF CODE STARTS WHICH CALLS BVNCDF HERE */
  for (i = 0; i < 2; i++) {
    s[i] = sqrt(Sigma[i * 3]);
  }

  for (i0 = 0; i0 < 2; i0++) {
    for (i = 0; i < 2; i++) {
      Rho[i0 + (i << 1)] = Sigma[i0 + (i << 1)] / (s[i0] * s[i]);
    }
  }

  /*  tol = 1e-8; */
  P = 0.0;
  for (i0 = 0; i0 < 2; i0++) {
    b_XL0 = (a[i0] - msifkh[i0]) / s[i0];
    XU0[i0] = (b[i0] - msifkh[i0]) / s[i0];
    hyperectangle[i0 << 2] = b_XL0;
    XL0[i0] = b_XL0;
  }

  hyperectangle[1] = XL0[0];
  hyperectangle[5] = XU0[1];
  hyperectangle[2] = XU0[0];
  hyperectangle[6] = XL0[1];
  for (i0 = 0; i0 < 2; i0++) {
    hyperectangle[3 + (i0 << 2)] = XU0[i0];
  }

  for (i = 0; i < 4; i++) {
    for (i0 = 0; i0 < 2; i0++) {
      s[i0] = hyperectangle[i + (i0 << 2)];
    }

    P += rt_powd_snf(-1.0, iv0[i]) * WASPMOTEbvncdfforBME(s, Rho[1]);
  }

  dv0[0] = P;
  x = (P < 0.0);
  i = 0;
  if (x) {
    i = 1;
  }

  i0 = 0;
  while (i0 <= i - 1) {
    dv0[0] = 0.0;
    i0 = 1;
  }

  dv1[0] = dv0[0];
  x = (dv0[0] > 1.0);
  i = 0;
  if (x) {
    i = 1;
  }

  i0 = 0;
  while (i0 <= i - 1) {
    dv1[0] = 1.0;
    i0 = 1;
  }

  /*  [P]=WASPMOTEmvncdfforBME(XL,XU,mu,Sigma); */
  i = 1;
  P = dv1[0];
  if (rtIsNaN(dv1[0])) {
    i = 2;
    P = 9.88131291682493E-324;
  }

  if ((i < 2) && (9.88131291682493E-324 > P)) {
    P = 9.88131291682493E-324;
  }

  /*  make sure that log(P) does not yield -Inf */
  b_XL0 = 0.0;
  for (i0 = 0; i0 < 4; i0++) {
    Sigma[i0] = 0.0;
    for (i = 0; i < 4; i++) {
      Sigma[i0] += zkh[i] * invKkhkh[i + (i0 << 2)];
    }

    b_XL0 += Sigma[i0] * zkh[i0];
  }

  f = 0.5 * b_XL0 - log(P);

  /*  compute the value of the -log posterior pdf */
  return f;
}

/*
 * File trailer for WASPMOTEfminBMEintervalMode.c
 *
 * [EOF]
 */
