/*
 * File: WASPMOTEfminbnd.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:07:22
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEfminbnd.h"
#include "WASPMOTEfminBMEintervalMode.h"

/* Function Definitions */

/*
 * FMINBND Single-variable bounded nonlinear function minimization.
 *    X = FMINBND(FUN,x1,x2) attempts to find  a local minimizer X of the function
 *    FUN in the interval x1 < X < x2.  FUN is a function handle.  FUN accepts
 *    scalar input X and returns a scalar function value F evaluated at X.
 * Arguments    : double ax
 *                double bx
 *                const double zhlocal[3]
 *                const double alocal[2]
 *                const double blocal[2]
 *                const double invKkhkh[16]
 *                const double KskhinvKkhkh[8]
 *                const double Kssifkh[4]
 * Return Type  : double
 */
double WASPMOTEfminbnd(double ax, double bx, const double zhlocal[3], const
  double alocal[2], const double blocal[2], const double invKkhkh[16], const
  double KskhinvKkhkh[8], const double Kssifkh[4])
{
  double xf;
  double a;
  double b;
  double v;
  double w;
  double d;
  double e;
  double fx;
  double fv;
  double fw;
  double xm;
  double tol1;
  double tol2;
  int gs;
  double r;
  double q;
  double p;
  double b_q;
  double b_d;
  double b_r;

  /*  function xf = WASPMOTEfminbnd(funfcn,ax,bx,zhlocal,alocal,blocal,invKkhkh,KskhinvKkhkh,Kssifkh) */
  /* % I am attaching a C code(brent.c) and header files( brent.h) for this code. we just need to define our function handle ( funfcn  variable) here. In this programm  */
  /* %I am definig function handler inside program, while in C code, they pass function handlers in function arguments.  */
  /* % Input Function for FminBND */
  /*  xf = []; */
  /*  fx = []; */
  a = ax;
  b = bx;
  v = ax + 0.3819660112501051 * (bx - ax);
  w = v;
  xf = v;
  d = 0.0;
  e = 0.0;
  fx = WASPMOTEfminBMEintervalMode(v, zhlocal, alocal, blocal, invKkhkh,
    KskhinvKkhkh, Kssifkh);
  fv = fx;
  fw = fx;
  xm = 0.5 * (ax + bx);
  tol1 = 1.4901161193847656E-8 * fabs(v) + 3.3333333333333335E-5;
  tol2 = 2.0 * tol1;

  /*  Main loop */
  while (fabs(xf - xm) > tol2 - 0.5 * (b - a)) {
    gs = 1;

    /*  Is a parabolic fit possible */
    if (fabs(e) > tol1) {
      /*  Yes, so fit parabola */
      gs = 0;
      r = (xf - w) * (fx - fv);
      q = (xf - v) * (fx - fw);
      p = (xf - v) * q - (xf - w) * r;
      q = 2.0 * (q - r);
      if (q > 0.0) {
        p = -p;
      }

      q = fabs(q);
      r = e;
      e = d;

      /*  Is the parabola acceptable */
      if ((fabs(p) < fabs(0.5 * q * r)) && (p > q * (a - xf)) && (p < q * (b -
            xf))) {
        /*  Yes, parabolic interpolation step */
        d = p / q;
        q = xf + d;

        /*  f must not be evaluated too close to ax or bx */
        if ((q - a < tol2) || (b - q < tol2)) {
          q = xm - xf;
          if (q < 0.0) {
            b_q = -1.0;
          } else if (q > 0.0) {
            b_q = 1.0;
          } else if (q == 0.0) {
            b_q = 0.0;
          } else {
            b_q = q;
          }

          d = tol1 * (b_q + (double)(xm - xf == 0.0));
        }
      } else {
        /*  Not acceptable, must do a golden section step */
        gs = 1;
      }
    }

    if (gs != 0) {
      /*  A golden-section step is required */
      if (xf >= xm) {
        e = a - xf;
      } else {
        e = b - xf;
      }

      d = 0.3819660112501051 * e;
    }

    /*  The function must not be evaluated too close to xf */
    r = fabs(d);
    if (d < 0.0) {
      b_d = -1.0;
    } else if (d > 0.0) {
      b_d = 1.0;
    } else if (d == 0.0) {
      b_d = 0.0;
    } else {
      b_d = d;
    }

    if ((r >= tol1) || rtIsNaN(tol1)) {
      b_r = r;
    } else {
      b_r = tol1;
    }

    q = xf + (b_d + (double)(d == 0.0)) * b_r;
    r = WASPMOTEfminBMEintervalMode(q, zhlocal, alocal, blocal, invKkhkh,
      KskhinvKkhkh, Kssifkh);

    /*  Update a, b, v, w, x, xm, tol1, tol2 */
    if (r <= fx) {
      if (q >= xf) {
        a = xf;
      } else {
        b = xf;
      }

      v = w;
      fv = fw;
      w = xf;
      fw = fx;
      xf = q;
      fx = r;
    } else {
      /*  fu > fx */
      if (q < xf) {
        a = q;
      } else {
        b = q;
      }

      if ((r <= fw) || (w == xf)) {
        v = w;
        fv = fw;
        w = q;
        fw = r;
      } else {
        if ((r <= fv) || (v == xf) || (v == w)) {
          v = q;
          fv = r;
        }
      }
    }

    xm = 0.5 * (a + b);
    tol1 = 1.4901161193847656E-8 * fabs(xf) + 3.3333333333333335E-5;
    tol2 = 2.0 * tol1;
  }

  /*  while */
  /*  fval = fx; */
  return xf;
}

/*
 * File trailer for WASPMOTEfminbnd.c
 *
 * [EOF]
 */
