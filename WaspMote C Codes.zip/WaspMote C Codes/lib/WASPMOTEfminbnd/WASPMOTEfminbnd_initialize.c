/*
 * File: WASPMOTEfminbnd_initialize.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:07:22
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEfminbnd.h"
#include "WASPMOTEfminbnd_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void WASPMOTEfminbnd_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for WASPMOTEfminbnd_initialize.c
 *
 * [EOF]
 */
