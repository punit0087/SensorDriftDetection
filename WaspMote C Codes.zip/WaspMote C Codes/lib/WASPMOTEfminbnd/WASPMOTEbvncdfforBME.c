/*
 * File: WASPMOTEbvncdfforBME.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:07:22
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WASPMOTEfminbnd.h"
#include "WASPMOTEbvncdfforBME.h"

/* Function Definitions */

/*
 * CDF for the bivariate normal.
 *   n = size(b,1);
 * Arguments    : const double b[2]
 *                double rho
 * Return Type  : double
 */
double WASPMOTEbvncdfforBME(const double b[2], double rho)
{
  double p;
  double n_cdf[2];
  int nd2;
  double hk;
  double ssq;
  double b_b;
  int w_size_idx_1;
  int y_size_idx_1;
  static const double dv2[3] = { 0.46791393457269043, 0.36076157304813838,
    0.1713244923791705 };

  double w_data[20];
  static const double dv3[3] = { 0.238619186083197, 0.6612093864662647,
    0.93246951420315216 };

  double y_data[10];
  static const double dv4[6] = { 0.24914704581340291, 0.23349253653835469,
    0.2031674267230659, 0.16007832854334639, 0.1069393259953183,
    0.047175336386511772 };

  static const double dv5[6] = { 0.12523340851146919, 0.36783149899818018,
    0.58731795428661715, 0.769902674194305, 0.904117256370475,
    0.98156063424671913 };

  static const double dv6[10] = { 0.15275338713072589, 0.14917298647260371,
    0.1420961093183821, 0.13168863844917661, 0.1181945319615184,
    0.1019301198172404, 0.083276741576704755, 0.062672048334109054,
    0.040601429800386939, 0.017614007139152121 };

  static const double dv7[10] = { 0.076526521133497324, 0.2277858511416451,
    0.3737060887154196, 0.51086700195082713, 0.636053680726515,
    0.7463319064601508, 0.83911697182221878, 0.912234428251326,
    0.96397192727791381, 0.99312859918509488 };

  double asinrho;
  int ww_size_idx_1;
  double ww_data[20];
  int b_j1;
  int j2;
  double theta_data[20];
  double sintheta_data[20];
  signed char x_size[2];
  double x_data[20];
  signed char x[2];
  p = 0.0;

  /* %% Compute Normal CDF here  */
  for (nd2 = 0; nd2 < 2; nd2++) {
    hk = fabs(b[nd2]) / 1.4142135623730951;
    ssq = 1.0 / (1.0 + 0.3275911 * hk);
    hk *= -hk;
    hk = exp(hk);
    if (b[nd2] < 0.0) {
      b_b = -1.0;
    } else if (b[nd2] > 0.0) {
      b_b = 1.0;
    } else if (b[nd2] == 0.0) {
      b_b = 0.0;
    } else {
      b_b = b[nd2];
    }

    n_cdf[nd2] = 0.5 * (1.0 + b_b * (1.0 - ((((1.061405429 * ssq + -1.453152027)
      * ssq + 1.421413741) * ssq + -0.284496736) * ssq + 0.254829592) * ssq * hk));
  }

  /* % n_cdf  is norm cdf */
  if (rho == 0.0) {
    p = n_cdf[0] * n_cdf[1];

    /* % make it type of double using cast ( check bvncdf code) */
  } else {
    if (fabs(rho) < 0.3) {
      /*  6 point Gauss Legendre abscissas and weights */
      w_size_idx_1 = 3;
      y_size_idx_1 = 3;
      for (nd2 = 0; nd2 < 3; nd2++) {
        w_data[nd2] = dv2[nd2];
        y_data[nd2] = dv3[nd2];
      }
    } else if (fabs(rho) < 0.75) {
      /*  12 point Gauss Legendre abscissas and weights */
      w_size_idx_1 = 6;
      y_size_idx_1 = 6;
      for (nd2 = 0; nd2 < 6; nd2++) {
        w_data[nd2] = dv4[nd2];
        y_data[nd2] = dv5[nd2];
      }
    } else {
      /*  20 point Gauss Legendre abscissas and weights */
      w_size_idx_1 = 10;
      y_size_idx_1 = 10;
      for (nd2 = 0; nd2 < 10; nd2++) {
        w_data[nd2] = dv6[nd2];
        y_data[nd2] = dv7[nd2];
      }
    }

    if (fabs(rho) < 0.925) {
      /* % function comes here */
      /* % product of columns from Phi or normcdf */
      asinrho = asin(rho);

      /* % arc sin function available in math.h */
      ww_size_idx_1 = w_size_idx_1 + w_size_idx_1;
      for (nd2 = 0; nd2 < w_size_idx_1; nd2++) {
        ww_data[nd2] = w_data[nd2];
      }

      for (nd2 = 0; nd2 < w_size_idx_1; nd2++) {
        ww_data[nd2 + w_size_idx_1] = w_data[nd2];
      }

      /* % duplicate w  */
      w_size_idx_1 = ww_size_idx_1;
      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        w_data[nd2] = ww_data[nd2];
      }

      nd2 = ww_size_idx_1 >> 1;
      for (b_j1 = 1; b_j1 <= nd2; b_j1++) {
        j2 = ww_size_idx_1 - b_j1;
        hk = w_data[b_j1 - 1];
        w_data[b_j1 - 1] = w_data[j2];
        w_data[j2] = hk;
      }

      /* % make reverse order */
      ww_size_idx_1 = y_size_idx_1 + y_size_idx_1;
      for (nd2 = 0; nd2 < y_size_idx_1; nd2++) {
        ww_data[nd2] = y_data[nd2];
      }

      for (nd2 = 0; nd2 < y_size_idx_1; nd2++) {
        ww_data[nd2 + y_size_idx_1] = -y_data[nd2];
      }

      /* % duplicate y with negative sign */
      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        theta_data[nd2] = ww_data[nd2];
      }

      nd2 = ww_size_idx_1 >> 1;
      for (b_j1 = 1; b_j1 <= nd2; b_j1++) {
        j2 = ww_size_idx_1 - b_j1;
        hk = theta_data[b_j1 - 1];
        theta_data[b_j1 - 1] = theta_data[j2];
        theta_data[j2] = hk;
      }

      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        theta_data[nd2] = asinrho * (theta_data[nd2] + 1.0) / 2.0;
      }

      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        sintheta_data[nd2] = theta_data[nd2];
      }

      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        sintheta_data[nd2] = sin(sintheta_data[nd2]);
      }

      x_size[0] = 1;
      x_size[1] = (signed char)ww_size_idx_1;
      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        x_data[nd2] = theta_data[nd2];
      }

      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        x_data[nd2] = cos(x_data[nd2]);
      }

      for (nd2 = 0; nd2 < 2; nd2++) {
        x[nd2] = x_size[nd2];
      }

      for (nd2 = 0; nd2 < x[1]; nd2++) {
        ww_data[nd2] = x_data[nd2] * x_data[nd2];
      }

      /*  always positive */
      hk = -b[0] * -b[1];
      ssq = (-b[0] * -b[0] + -b[1] * -b[1]) / 2.0;
      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        sintheta_data[nd2] = -(ssq - hk * sintheta_data[nd2]) / ww_data[nd2];
      }

      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        ww_data[nd2] = sintheta_data[nd2];
      }

      for (nd2 = 0; nd2 < ww_size_idx_1; nd2++) {
        ww_data[nd2] = exp(ww_data[nd2]);
      }

      for (nd2 = 0; nd2 < w_size_idx_1; nd2++) {
        w_data[nd2] *= ww_data[nd2];
      }

      hk = w_data[0];
      for (nd2 = 2; nd2 <= w_size_idx_1; nd2++) {
        hk += w_data[nd2 - 1];
      }

      p = n_cdf[0] * n_cdf[1] + asinrho * hk / 2.0 / 6.2831853071795862;
    }
  }

  return p;
}

/*
 * File trailer for WASPMOTEbvncdfforBME.c
 *
 * [EOF]
 */
