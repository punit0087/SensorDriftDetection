/*
 * File: WASPMOTEfminbnd_terminate.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-Mar-2016 04:07:22
 */

#ifndef __WASPMOTEFMINBND_TERMINATE_H__
#define __WASPMOTEFMINBND_TERMINATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WASPMOTEfminbnd_types.h"

/* Function Declarations */
extern void WASPMOTEfminbnd_terminate(void);

#endif

/*
 * File trailer for WASPMOTEfminbnd_terminate.h
 *
 * [EOF]
 */
