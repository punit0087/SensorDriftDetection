function p = WaspmotebvncdfforBME(b,rho)
% CDF for the bivariate normal.
 
% Implements Section 2.4 of Genz (2004).

n = size(b,1);
if rho == 0
    Temp=WASPMOTEnormcdf(b);
    p = Temp(1)*Temp(2); %% make it type of double using cast ( check bvncdf code)
else
    if abs(rho) < 0.3      % 6 point Gauss Legendre abscissas and weights
        w = [0.4679139345726904  0.3607615730481384  0.1713244923791705];
        y = [0.2386191860831970  0.6612093864662647  0.9324695142031522];
    elseif abs(rho) < 0.75 % 12 point Gauss Legendre abscissas and weights
        w = [0.2491470458134029  0.2334925365383547  0.2031674267230659 ...
             0.1600783285433464  0.1069393259953183  0.04717533638651177];
        y = [0.1252334085114692  0.3678314989981802  0.5873179542866171 ...
             0.7699026741943050  0.9041172563704750  0.9815606342467191];
    else                 % 20 point Gauss Legendre abscissas and weights
        w = [0.1527533871307259  0.1491729864726037  0.1420961093183821  0.1316886384491766  0.1181945319615184 ...
             0.1019301198172404  0.08327674157670475 0.06267204833410906 0.04060142980038694 0.01761400713915212];
        y = [0.07652652113349733 0.2277858511416451  0.3737060887154196  0.5108670019508271  0.6360536807265150 ...
             0.7463319064601508  0.8391169718222188  0.9122344282513259  0.9639719272779138  0.9931285991850949];
    end
    
    if abs(rho) < .925 %% function comes here
        p1 = prod(WASPMOTEnormcdf(b),2); %% product of columns from Phi or normcdf
        asinrho = asin(rho);  %% arc sin function available in math.h
        ww=[w w]; %% duplicate w 
        w = fliplr(ww);  %% make reverse order
        ymy=[y -y]; %% duplicate y with negative sign
        theta = asinrho .* (fliplr(ymy) + 1) / 2;
        sintheta = sin(theta);
        cossqtheta = cos(theta).^2; % always positive
        h = -b(:,1);
        k = -b(:,2);
        hk = h .* k;
        ssq = (h.^2 + k.^2) / 2;
        f = exp( -(ssq - hk*sintheta) ./ cossqtheta );
        p2 = asinrho * sum(w.*f) / 2;
        p = p1 + p2/(2*pi);
     end
end
end % bvncdf












