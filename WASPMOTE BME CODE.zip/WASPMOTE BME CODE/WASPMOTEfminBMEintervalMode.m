function [f]=WASPMOTEfminBMEintervalMode(zk,zh,a,b,invKkhkh,KskhinvKkhkh,Kssifkh,options);

zkh=[zk;zh];
msifkh=KskhinvKkhkh*zkh;          % compute the conditional mean
[P,evalerr,INFOINTEG]=mvnAG1(a-msifkh,b-msifkh,Kssifkh,options(3),0,options(4));
New_Kssifkh=(Kssifkh+Kssifkh')/2;
muVec= zeros(size(New_Kssifkh,1),1);

XL=a-msifkh;
XU=b-msifkh;
mu=zeros(size(New_Kssifkh,1),1);
Sigma=(Kssifkh+Kssifkh')/2;

% Q=0;
% L=XL; LU=[XL(1);XU(2)]; UL=[XU(1);XL(2)]; U=XU;
% hyperectangle=[L LU UL U];
% power=[0,1,1,2];
% 
% for i=1:4
% X=hyperectangle(:,i);
% tic
% Q=Q+(-1)^power(i)*TestMVNbyGANZ(X, mu, Sigma);
% time=toc
% end

%[Q,err]=WASPMOTEmvncdfforBME(XL,XU,mu,Sigma);
%P=Q;

P=max([P,1e-323]);                % make sure that log(P) does not yield -Inf
f=0.5*(zkh'*invKkhkh*zkh)-log(P); % compute the value of the -log posterior pdf
