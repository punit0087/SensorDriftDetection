function [mkest,mhest,msest,vkest]=WASPMOTElocalmeanBME(ck,ch,cs,zh,ms,vs,Khh,Ksh,Kss,order);

% localmeanBME              - local mean estimation for BME (Jan 1,2001)
%
% Compute the estimates for the mean at estimation, hard and
% soft data locations using generalized least squares, where
% the additional variance for the soft data is computed from 
% uniform distributions.
%
% SYNTAX :
%
% [mkest,mhest,msest,vkest]=localmeanBME(ck,ch,cs,zh,ms,vs,Khh,Ksh,Kss,order);
%
% INPUT :
%
% ck         1 by d     vector of coordinates for the estimation points,
%                       where d is the dimension of the space.
% ch         nh by d    matrix of coordinates for the hard data.
% cs         ns by d    matrix of coordinates for the soft data.
% zh         nh by 1    vector of the values for the hard data at ch.
% ms         ns by 1    vector of the mean values for the intervals at cs.
% vs         ns by 1    vector of the variance values for the uniform
%                       distributions defined by the intervals at cs.
% Khh        nh by nh   covariance matrix for the hard data.
% Ksh        ns by nh   covariance matrix between hard and soft data.
% Kss        ns by ns   covariance matrix for the soft data.
% order      scalar     that gives the order of the polynomial mean.
%
% OUTPUT :
%
% mkest      scalar     estimate of the mean for the estimation location.
% mhest      nh by 1    vector of estimate of the mean for hard data locations.
% msest      ns by 1    vector of estimate of the mean for soft data locations.
% vkest      scalar     variance of the estimated mean at zk.

nh=3;
ns=2;


c=[ch;cs]; %c=[21.5000000000000,23;33.5000000000000,28;22.5000000000000,8;19.5000000000000,19;22.5000000000000,15];

Kss=Kss+diag(vs); %% based on data
K=[Khh,Ksh';Ksh,Kss];
z=[zh;ms];

[best,Vbest,m,index]=bmeregression(c,z,order,K);

mhest=m(1:nh,1);
msest=m(nh+1:nh+ns,1);
mkest=best;
vkest=Vbest;

