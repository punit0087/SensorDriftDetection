function p = WASPMOTEnormcdf(z)
% CDF for the normal distribution.
    
        %% Approximation 1
    a1 =  0.254829592;
    a2 = -0.284496736;
    a3 =  1.421413741;
    a4 = -1.453152027;
    a5 =  1.061405429;
    pr  =  0.3275911;
    
    x = abs(z)/sqrt(2.0);

    t = 1.0./(1.0 + pr*x);
    y = 1.0 - (((((a5.*t + a4).*t) + a3).*t + a2).*t + a1).*t.*exp(-x.*x);  
    p1= 0.5.*(1.0 + sign(z).*y);
    p=p1;

   
    %% Approximation 2 Possible 
%     b1 =  0.31938153;
%     b2 = -0.356563782;
%     b3 =  1.781477937;
%     b4 = -1.821255978;
%     b5 =  1.330274429;
%     pr1  = 0.2316419; 
%     c2=0.3989423;
%     
%    a=abs(z);
%    t1 = 1.0./(1.0 + pr1*a);
%    b=c2.*exp((-z).*(z./2.0));
%    n=(((((b5.*t + b4).*t) + b3).*t + b2).*t + b1).*t1;
%    pr2 = 1.0 -b.*n; 

end

   