function [y,err] = WASPMOTEmvncdfforBME(XL,XU,mu,Sigma)

%   Y = MVNCDF(XL,XU,MU,SIGMA) returns the multivariate normal cumulative
%   probability evaluated over the rectangle (hyper-rectangle for D>2) 
%   with lower and upper limits defined by XL and XU, respectively.

d=2; % we are computing bivariate cdf
n=1;

XL0 = XL - mu;
XU0 = XU - mu;

XL0 = XL0';
XU0 = XU0';
err= 1.000E-08;

s = sqrt(diag(Sigma));
Rho = Sigma ./ (s*s');
XL0 = bsxfun(@rdivide,XL0,s');
XU0 = bsxfun(@rdivide,XU0,s');

tol = 1e-8;
rho = Rho(2); 

y=0;
L=XL0; LU=[XL0(1),XU0(2)]; UL=[XU0(1),XL0(2)]; U=XU0;
hyperectangle=[L;LU;UL;U];
power=[0,1,1,2];

for i=1:4
X=hyperectangle(i,:);
y=y+(-1)^power(i)*WaspmotebvncdfforBME(X, rho);
end

y(y<0) = 0;
y(y>1) = 1; 
end

