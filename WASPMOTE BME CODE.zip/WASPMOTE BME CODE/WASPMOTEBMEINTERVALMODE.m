% function [zk]=WASPMOTEBMEINTERVALMODE(ck,ch,cs,zh,a,b)

% BMEintervalMode           - BME mode prediction with interval data (Jan 1,2001)
%
% Compute at a set of estimation locations the mode of the
% posterior probability distribution function using both
% hard and interval soft data, where the mode is the most
% likely value.
%
% SYNTAX :
%
% [zk,info]=BMEintervalMode(ck,ch,cs,zh,a,b,covmodel,covparam,nhmax,nsmax,dmax,order,options);
%
% INPUT :
%
% ck         nk by d      matrix of coordinates for the estimation locations.
%                         A line corresponds to the vector of coordinates at
%                         an estimation location, so the number of columns
%                         corresponds to the dimension of the space. There is
%                         no restriction on the dimension of the space.
% ch         nh by d      matrix of coordinates for the hard data locations,
%                         with the same convention as for ck.
% cs         ns by d      matrix of coordinates for the soft data locations,
%                         with the same convention as for ck.
% zh         nh by 1      vector of values for the hard data at the coordinates
%                         specified in ch.
% a          ns by 1      vector of values for the lower bound of the intervals
%                         at the coordinates specified in cs.
% b          ns by 1      vector of values for the upper bound of the intervals
%                         at the coordinates specified in cs.
% covmodel   string       string that contains the name of the covariance model
%                         that is used for the estimation (see the modelslib directory).
%                         Variogram models are not available for this function.
% covparam   1 by k       vector of values for the parameters of covmodel, according
%                         to the convention for the corresponding covariance model.
% nhmax      scalar       maximum number of hard data values that are considered
%                         for the estimation at the locations specified in ck.
% nsmax      scalar       maximum number of soft data values that are considered for
%                         the estimation at the locations specified in ck. As the
%                         computation time is exponentially increasing with nsmax,
%                         it is not advised to use more than few soft data locations.
%                         In any case, nsmax should be lower than 20 in order to
%                         avoid numerical computation problems.
% dmax       scalar       maximum distance between an estimation location and
%                         existing hard/soft data locations. All hard/soft data
%                         locations separated by a distance smaller than dmax from an
%                         estimation location will be included in the estimation process
%                         for that location, whereas other data locations are neglected.
% order      scalar       order of the polynomial drift along the spatial axes at the
%                         estimation locations. For the zero-mean case, NaN (Not-a-Number)
%                         is used.
% options    1 by 1 or 14 vector of optional parameters that can be used if default
%                         values are not satisfactory (otherwise this vector can simply be
%                         omitted from the input list of variables), where :
%                         options(1), options(2) and options(14) are values used by the
%                         fminbnd.m MATLAB optimization routine that finds the mode of the
%                         probability distribution function (default values are the same
%                         as for fminbnd.m),
%                         options(3) specifies the maximum number of evaluation that can
%                         be done by the FORTRAN77 subroutines for the integrals (default
%                         value is 50 000 ; this value should be increased if a warning
%                         message appears on the screen during the computation),
%                         options(4) specifies the maximum admissible relative error on the
%                         estimation of these integrals (default value is 1e-4). The values
%                         for options(5) to options(13) are not used.
%
% OUTPUT :
%
% zk         nk by 1      vector of estimated values at the estimation locations. A value
%                         coded as NaN means that no estimation has been performed at that
%                         location due to the lack of available data.
% info       nk by 1      vector for information about the computation of estimated values.
%                         Different possible values are :
%                         info=NaN if there is no computation at all (no hard and soft data
%                         are available around or at the estimation location),
%                         info=0 when computation is made using BME with at least 1 soft data,
%                         info=1 when the estimation is dubious due to an integration error
%                         above the tolerance specified in options(4),
%                         info=2 when the estimation is dubious as the result did not converge
%                         within the maximum number of iterations specified in options(14),
%                         info=3 when the computation is made using kriging with no soft data,
%                         info=4 when there is a hard data value at the estimation location,
%                         info=5 when there is only an interval at the estimation location
%                         (the output zk value is then the middle of this interval).
%
% NOTE :
%
% 1- Note that in the case there are no available hard data at all,
% ch and zh can be entered as the empty [ ] matrices.
%
% 2-  All the specific conventions for specifying nested models,
% multivariate or space-time cases are the same as for BMEprobaMoments.m.

%%%%%% Error messages

%%%%%% Initialize the parameters



nk=1;           % nk is the number of estimation points
nh=3;           % nh is the number of hard data
ns=2;           % ns is the number of soft data

total=nh+ns;


zk=zeros(1,1)*NaN; %% Not known what is going on here
info=zeros(1,1)*NaN;

%%%%%% Main loop starts here


%IBRL Sample DATA%%%%%%%%

% covmodel={'nuggetC','exponentialC'};
% covparam={-0.0795000000000000,[0.665600000000000,22.3507000000000]};
% order=0;
% dmax=100;
% ck0=[24.5,20];
% chlocal=[21.5,23;33.5,28;22.5,8];
% cslocal=[19.5,19;22.5,15];
% 
% % ablocal=[20.7843,21.7843;21.0466,22.0466];
% 
%  zhlocal=[21.0475;21.4999;21.2314];
%  alocal=[20.7843;21.0466];
%  blocal=[21.7843;22.0466];
% 
% Khh=[0.5861,0.1163,0.0885;0.1163,0.5861,0.0311;0.0885,0.0311,0.5861];
% Kss=[0.5861,0.3402;0.3402,0.5861]; 
% Ksh=[0.3652,0.0713,0.1440;0.2255,0.0677,0.2601];
% 
% invKkhkh= [3.03751008042635,-1.83460168015313,-0.301101335707301,-0.380947972560897;-1.83460168015313,2.92148073795342,-0.164284024311862,-0.0253344226212212;-0.301101335707301,-0.164284024311862,1.80692806065874,-0.00425196850242675;-0.380947972560897,-0.0253344226212212,-0.00425196850242675,1.79476123606600];
% KskhinvKkhkh=[0.273424511692489,0.435624332363198,-0.0328775008809324,0.121124463523203;0.448064573284860,0.0485231814344831,-0.0131264156019486,0.337767948574806];
% Kssifkh=[0.320113121342157,0.124340944117798;0.124340944117798,0.343429423349117];

  



% ISSNIP Sample DATA%%%%%%%%

% data=xlsread('WASPMOTE LAB DATA.xlsx');
% Int5=0.5;

covmodel={'exponentialC'};
covparam={[0.5046,10.3602]};
order=0;
dmax=100;

Hard_Sensors=[3,4,5];
Soft_Sensors=[2,6];

mote_position= [15,8;2,0;2,8;7,2;17,0;17,8];

chlocal= mote_position(Hard_Sensors,:);
cslocal= mote_position(Soft_Sensors,:);
ck0= mote_position(1,:);


% ablocal=[20.7843,21.7843;21.0466,22.0466];

zhlocal=[23.2299995422000;24.5199985504000;24.5199985504000];
alocal=[23.6311;23.6470];
blocal=[24.6311;24.6470];

Khh=[0.5046,0.05257,0.00367;0.05257,0.5046,0.02633;0.00367,0.0263,0.5046];
Kss=[0.5046,0.00367;0.00367,0.5046];
Ksh=[0.0498,0.1061,0.0066;0.0066,0.0172,0.0498];
invKkhkh=[2.00439204645087,-0.0349751655110108,-0.0977952680621714,-0.178698944288472;-0.0349751655110108,2.00413103056033,-0.206832002312290,-0.000584906818928333;-0.0977952680621714,-0.206832002312290,2.01365588406215,-0.0945880638118943;-0.178698944288472,-0.000584906818928333,-0.0945880638118943,2.00311698575523];
KskhinvKkhkh=[-0.00111730837005529,0.0775641085244523,0.202143867898359,0.00198035211538520;0.555971244042237,-0.000346338668600935,0.000985706958887273,0.0475105854497376];
Kssifkh=[0.479286686597638,-0.000101331903950445;-0.000101331903950445,0.345010308482887];


mslocal=(alocal+blocal)/2;                      % compute the mean assuming uniform distribution
vslocal=((blocal-alocal).^2)/12;                % compute the variance assuming uniform distribution

c=[chlocal;cslocal]; %c=[21.5000000000000,23;33.5000000000000,28;22.5000000000000,8;19.5000000000000,19;22.5000000000000,15];

Kss=Kss+diag(vslocal); %% based on data
K=[Khh,Ksh';Ksh,Kss];
z=[zhlocal;mslocal];

X=ones(total,1);
Xt=X';

%%BME REGRESSION
XtinvK=X'*inv(K);
invXtinvKX=inv(XtinvK*X);
mkest=invXtinvKX*XtinvK*z;
zest=X*mkest;
vbest=invXtinvKX;

mhest=zest(1:nh,1);
msest=zest(nh+1:nh+ns,1);


zhlocal=zhlocal-mhest;                          % substract the mean from the hard data
alocal=alocal-msest;                            % substract the mean from the soft data
blocal=blocal-msest;

zkmin=min([zhlocal;alocal;0]);                % initialize the minimum and maximum guess
zkmax=max([zhlocal;blocal;0]);                % values to be used by fminbnd


zk=WASPMOTEfminbnd(zkmin,zkmax,...
    zhlocal,alocal,blocal,invKkhkh,KskhinvKkhkh,Kssifkh);

zk=zk+mkest;                                 % add the mean to the mode estimate

zk
